# Opdracht Members...

Maak een member registration form met volgende velden:

- Voornaam (verplicht, max 100)
- Naam (verplicht, max 100)
- Username (verplicht, max 20, uniek)
- Gender (verplicht, m|f|x)
- photo (optioneel, URL naar afbeelding online)

Maak daarbij gebruik van de members table in bijgevoegde members.sql

Voorzie twee pagina:

1. registration form met formulier + validatie + duidelijke foutboodschappen + feedback indien ok
2. een admin pagina waar een overzicht getoond wordt van alle members en ik members kan deleten indien
